======
parser
======
.. automodule:: dateutil.parser
   :members:
   :undoc-members:
