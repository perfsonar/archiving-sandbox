=====
rrule
=====

.. automodule:: dateutil.rrule
   :members:
   :undoc-members:
